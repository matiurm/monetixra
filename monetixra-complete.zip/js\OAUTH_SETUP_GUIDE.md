# OAuth Setup Guide for Monetixra

This guide explains how to configure OAuth authentication for Google, Facebook, Apple, Twitter/X, Line, and Kakao.

## Overview

The OAuth system in Monetixra allows users to sign in using their existing social media accounts. This provides a seamless onboarding experience and improves user conversion.

## Login Methods

The system supports three login methods:

1. **Popup Login (`oauthLogin`)** - Opens OAuth provider in a popup window (best for desktop)
2. **Redirect Login (`oauthLoginRedirect`)** - Directly redirects to OAuth provider (best for mobile)
3. **Smart Login (`oauthLoginSmart`)** - Automatically detects device type and uses the best method

### Usage Examples

```html
<!-- Popup Login (Desktop) -->
<button onclick="oauthLogin('google')">Sign in with Google</button>

<!-- Redirect Login (Mobile) -->
<button onclick="oauthLoginRedirect('google')">Sign in with Google</button>

<!-- Smart Login (Auto-detects device) -->
<button onclick="oauthLoginSmart('google')">Sign in with Google</button>
```

## Supported Providers

- **Google** - Google OAuth 2.0
- **Facebook** - Facebook Login
- **Apple** - Sign in with Apple
- **Twitter/X** - Twitter OAuth 2.0
- **Line** - Line Login
- **Kakao** - Kakao Login

## Configuration Steps

### 1. Google OAuth Setup

1. Go to [Google Cloud Console](https://console.cloud.google.com/)
2. Create a new project or select existing one
3. Enable Google+ API and Google Identity Services
4. Go to **Credentials** → **Create Credentials** → **OAuth client ID**
5. Select **Web application**
6. Add authorized redirect URIs:
   - `https://yourdomain.com/auth/google/callback`
   - `http://localhost:3000/auth/google/callback` (for development)
7. Copy the **Client ID**
8. Add to your configuration:

```javascript
window.__MONETIXRA_CONFIG__ = {
  oauth: {
    google: {
      clientId: 'YOUR_GOOGLE_CLIENT_ID'
    }
  }
}
```

### 2. Facebook OAuth Setup

1. Go to [Facebook Developers](https://developers.facebook.com/)
2. Create a new app → Select **Consumer** or **Business**
3. Add **Facebook Login** product
4. In Settings → Basic, copy the **App ID**
5. In Settings → Facebook Login, add redirect URIs:
   - `https://yourdomain.com/auth/facebook/callback`
   - `http://localhost:3000/auth/facebook/callback`
6. Add to configuration:

```javascript
window.__MONETIXRA_CONFIG__ = {
  oauth: {
    facebook: {
      appId: 'YOUR_FACEBOOK_APP_ID'
    }
  }
}
```

### 3. Apple Sign In Setup

1. Go to [Apple Developer](https://developer.apple.com/)
2. Create a new App ID with **Sign in with Apple** capability
3. Create a new Service ID in **Certificates, Identifiers & Profiles**
4. Configure the Service ID with your redirect URIs:
   - `https://yourdomain.com/auth/apple/callback`
   - `http://localhost:3000/auth/apple/callback`
5. Copy the **Services ID** (Client ID)
6. Add to configuration:

```javascript
window.__MONETIXRA_CONFIG__ = {
  oauth: {
    apple: {
      clientId: 'YOUR_APPLE_SERVICE_ID'
    }
  }
}
```

**Note:** Apple requires HTTPS in production and a verified domain.

### 4. Twitter/X OAuth Setup

1. Go to [Twitter Developer Portal](https://developer.twitter.com/)
2. Create a new project and app
3. In **App settings**, enable **OAuth 2.0**
4. Configure **Callback URI**:
   - `https://yourdomain.com/auth/twitter/callback`
   - `http://localhost:3000/auth/twitter/callback`
5. Copy the **Client ID**
6. Add to configuration:

```javascript
window.__MONETIXRA_CONFIG__ = {
  oauth: {
    twitter: {
      clientId: 'YOUR_TWITTER_CLIENT_ID'
    }
  }
}
```

### 5. Line Login Setup

1. Go to [Line Developers](https://developers.line.biz/)
2. Create a new provider and channel
3. Select **Login** channel type
4. In Channel settings, add callback URL:
   - `https://yourdomain.com/auth/line/callback`
   - `http://localhost:3000/auth/line/callback`
5. Copy the **Channel ID**
6. Add to configuration:

```javascript
window.__MONETIXRA_CONFIG__ = {
  oauth: {
    line: {
      channelId: 'YOUR_LINE_CHANNEL_ID'
    }
  }
}
```

### 6. Kakao Login Setup

1. Go to [Kakao Developers](https://developers.kakao.com/)
2. Create a new app
3. In **App Settings** → **Platform**, add web platform
4. Add redirect URIs:
   - `https://yourdomain.com/auth/kakao/callback`
   - `http://localhost:3000/auth/kakao/callback`
5. Enable **Kakao Login** in product settings
6. Copy the **REST API Key** (Client ID)
7. Add to configuration:

```javascript
window.__MONETIXRA_CONFIG__ = {
  oauth: {
    kakao: {
      clientId: 'YOUR_KAKAO_CLIENT_ID'
    }
  }
}
```

## Backend Implementation

You need to implement the backend endpoint `/api/oauth/callback` to handle the OAuth flow:

```javascript
// Example Express.js backend endpoint
app.post('/api/oauth/callback', async (req, res) => {
  const { provider, code, redirectUri, verifier } = req.body;
  
  try {
    let tokenUrl, userInfoUrl, clientId, clientSecret;
    
    // Configure based on provider
    switch (provider) {
      case 'google':
        tokenUrl = 'https://oauth2.googleapis.com/token';
        userInfoUrl = 'https://www.googleapis.com/oauth2/v3/userinfo';
        clientId = process.env.GOOGLE_CLIENT_ID;
        clientSecret = process.env.GOOGLE_CLIENT_SECRET;
        break;
      // Add other providers...
    }
    
    // Exchange code for access token
    const tokenResponse = await fetch(tokenUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({
        client_id: clientId,
        client_secret: clientSecret,
        code: code,
        redirect_uri: redirectUri,
        grant_type: 'authorization_code',
        code_verifier: verifier
      })
    });
    
    const tokenData = await tokenResponse.json();
    
    // Get user info
    const userResponse = await fetch(userInfoUrl, {
      headers: { 'Authorization': `Bearer ${tokenData.access_token}` }
    });
    
    const userInfo = await userResponse.json();
    
    res.json({ success: true, userInfo, tokenData });
    
  } catch (error) {
    console.error('OAuth callback error:', error);
    res.status(500).json({ error: error.message });
  }
});
```

## Environment Variables

Add these to your `.env` file:

```env
# Google OAuth
GOOGLE_CLIENT_ID=your_google_client_id
GOOGLE_CLIENT_SECRET=your_google_client_secret

# Facebook OAuth
FACEBOOK_APP_ID=your_facebook_app_id
FACEBOOK_APP_SECRET=your_facebook_app_secret

# Apple OAuth
APPLE_SERVICE_ID=your_apple_service_id
APPLE_TEAM_ID=your_apple_team_id
APPLE_KEY_ID=your_apple_key_id
APPLE_PRIVATE_KEY=path_to_private_key.p8

# Twitter OAuth
TWITTER_CLIENT_ID=your_twitter_client_id
TWITTER_CLIENT_SECRET=your_twitter_client_secret

# Line OAuth
LINE_CHANNEL_ID=your_line_channel_id
LINE_CHANNEL_SECRET=your_line_channel_secret

# Kakao OAuth
KAKAO_CLIENT_ID=your_kakao_client_id
KAKAO_CLIENT_SECRET=your_kakao_client_secret
```

## Security Best Practices

1. **Always use HTTPS** in production
2. **Validate state parameter** to prevent CSRF attacks
3. **Use PKCE** (Proof Key for Code Exchange) for mobile apps
4. **Store secrets securely** - never commit to git
5. **Set appropriate token expiration** times
6. **Implement rate limiting** on OAuth endpoints
7. **Log OAuth events** for security monitoring

## Testing

To test OAuth locally:

1. Add `http://localhost:3000` as a redirect URI in each provider's dashboard
2. Ensure your development server is running on port 3000
3. Click each OAuth button and verify the flow
4. Check browser console for any errors

## Troubleshooting

### "Popup blocked" error
- Ensure popups are allowed for your domain
- Check browser popup blocker settings

### "Invalid OAuth state" error
- Clear browser cookies and try again
- Check that state is being generated and stored correctly

### "Client ID not configured" error
- Verify your configuration is loaded before OAuth buttons are clicked
- Check that `window.__MONETIXRA_CONFIG__` is properly set

### Provider-specific errors
- Check provider dashboard for app status
- Verify redirect URIs match exactly
- Ensure app is in "Live" mode (not testing)

## Configuration Example

Complete configuration in your HTML:

```html
<script>
window.__MONETIXRA_CONFIG__ = {
  oauth: {
    google: {
      clientId: '123456789-abc.apps.googleusercontent.com'
    },
    facebook: {
      appId: '1234567890123456'
    },
    apple: {
      clientId: 'com.yourapp.serviceid'
    },
    twitter: {
      clientId: 'your_twitter_client_id'
    },
    line: {
      channelId: '1234567890'
    },
    kakao: {
      clientId: 'your_kakao_client_id'
    }
  }
};
</script>
```

## Support

For issues or questions:
- Check the provider's documentation
- Review browser console logs
- Verify configuration matches provider dashboard settings
